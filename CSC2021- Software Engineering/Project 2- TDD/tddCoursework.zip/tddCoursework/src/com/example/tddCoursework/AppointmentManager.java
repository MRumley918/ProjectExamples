package com.example.tddCoursework;

import java.util.ArrayList;
import java.util.List;

public class AppointmentManager {
	// creates a list of patients
	List<Patient> patients = new ArrayList<Patient>();

	// adds a new patient to the list, and sets all the relevant data fields
	public void addPatient(String n, String a, String i, String dob) {
		Patient p = new Patient();
		p.setName(n);
		p.setAddress(a);
		p.setPhonenumber(i);
		p.setDob(dob);
		patients.add(p);
	}

	// returns a list of all the patients and their appointments
	public List<String> getpatients() {
		List<String> getPatients = new ArrayList<String>();
		// temp strings store data before its put into the list
		String temp;
		String temp2;
		// for loop iterates through patient list
		for (Patient p : patients) {
			// gets all the data from a patient
			temp = (p.getId() + " " + p.getName() + " " + p.getAddress() + " " + p.getPhonenumber() + " " + p.getDob()
					+ "\n");
			// adds the patient to the output list
			getPatients.add(temp);
			// nested for loop iterates through each patient's appointments
			for (Appointment a : p.appointments) {
				temp2 = (a.getDate() + " " + a.getDescription() + "\n");
				// adds each appointment to the list
				getPatients.add(temp2);
			}

		}
		// returns the list
		return getPatients;

	}

	// searches for a patient by their name
	public String searchPatient(String search) {
		// iterates through the list of patients
		for (Patient p : patients) {
			// if the search term equals a patients name their details are
			// returned
			if (search == p.getName()) {
				return (p.getId() + " " + p.getName() + " " + p.getAddress() + " " + p.getPhonenumber() + " "
						+ p.getDob());
			}
		}
		// otherwise a null value is returned
		return null;
	}

	// changes the name of a patient given their id
	public void changeName(int i, String n) {
		for (Patient p : patients) {
			if (p.getId() == i) {
				p.setName(n);
			}
		}
	}

	// changes the address of a patient given their id
	public void changeAddress(int i, String a) {
		for (Patient p : patients) {
			if (p.getId() == i) {
				p.setAddress(a);
			}
		}
	}

	// adds a new appointment to a patient given their id
	public void addAppointment(int i, String date, String description) {
		for (Patient p : patients) {
			if (p.getId() == i) {
				p.makeNewAppointment(date, description);
			}
		}
	}

}
