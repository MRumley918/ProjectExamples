package com.example.tddCoursework;

import java.util.ArrayList;
import java.util.List;

public class Patient {
	// declares the data fields that need storing
	private String name;
	private String address;
	private String phonenumber;
	private String dob;
	// creates a list of appointments
	List<Appointment> appointments = new ArrayList<Appointment>();

	// basic setters
	public void setName(String name) {
		this.name = name;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	// get id returns the hashcode- while this is adequate for this
	// specification however may be
	// impractical in other cases
	public int getId() {
		return this.hashCode();
	}

	// basic getters
	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public String getDob() {
		return dob;
	}

	// makes a new appointment, and sets the relevant values
	public void makeNewAppointment(String date, String description) {
		Appointment a = new Appointment();
		a.setDate(date);
		a.setDescription(description);
		// the appointment is added to the list of appointments
		appointments.add(a);
	}

}
