package com.example.tddCoursework;

public class Appointment {
	// the fields that are needed in an appointment
	private String date;
	private String description;

	// basic setters and getters
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
