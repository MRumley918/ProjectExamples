package com.example.tddCoursework;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

public class Task3Tests extends AbstractLoggingJUnitTest {
	// an appointment manager is created to test on
	AppointmentManager a = new AppointmentManager();

	// feature 6
	@Test
	public void testsearch() {
		// a patient is added to the appointment manager
		a.addPatient("Joe Bloggs", "64 Zoo Lane", "0776326494", "25/12/1995");
		// if the patient is searched for, data is returned
		assertNotNull(a.searchPatient("Joe Bloggs"));
		// if the name is not completely matching then no data is returned
		assertNull(a.searchPatient("Joe Blogs"));

	}

	// feature 7
	@Test
	public void testchanging() {
		// two identical patients are added to the appointment manager
		a.addPatient("Joe Bloggs", "64 Zoo Lane", "0776326494", "25/12/1995");
		a.addPatient("Joe Bloggs", "64 Zoo Lane", "0776326494", "25/12/1995");
		Patient p1 = a.patients.get(0);
		Patient p2 = a.patients.get(1);
		// tests confirm their names and addresses are the same
		assertEquals(p1.getName(), p2.getName());
		assertEquals(p1.getAddress(), p2.getAddress());
		// the second patient has their name and address changed by the 'change'
		// methods
		a.changeName(p2.getId(), "Jim Blaze");
		a.changeAddress(p2.getId(), "1122 Boogie Woogie Avenue");
		// the names and addresses of the two patients are now no longer the
		// same
		assertNotEquals(p1.getName(), p2.getName());
		assertNotEquals(p1.getAddress(), p2.getAddress());

	}

	// feature 8
	@Test
	public void testaddappointment() {
		// adds a new patient to the appointment manager
		a.addPatient("Joe Bloggs", "64 Zoo Lane", "0776326494", "25/12/1995");
		Patient p1 = a.patients.get(0);
		// creates an null list for testing purposes
		List<String> empty = null;
		// the appointments list for this patient is empty
		assert (p1.appointments.equals(empty));
		// an appointment is added through the appointment manager using the
		// patients id
		a.addAppointment(p1.getId(), "27/11/2016", "Test Appointment");
		// the appointments list for the patient is no longer empty
		assertFalse(p1.appointments.equals(empty));
	}
}
