package com.example.tddCoursework;

import static org.junit.Assert.*;

import org.junit.Test;

public class Task2Tests extends AbstractLoggingJUnitTest {
	// an initial instance of an appointment manager object is created for tests
	// to be run on
	AppointmentManager a = new AppointmentManager();

	// feature 1
	@Test
	public void testmultipleappointmentmanagers() {
		// an additional appointment manager is created
		AppointmentManager b = new AppointmentManager();
		// the new appointment manager differs from the already existing one,
		// proving multiple
		// instances of appointment manager can be created
		assertNotSame(a, b);
	}

	// feature 3
	@Test
	public void testinfostorage() {
		// a new patient is created in the appointment manager, with various
		// pieces of information
		// stored about them
		a.addPatient("Joe Bloggs", "64 Zoo Lane", "0776326494", "25/12/1995");
		// the newly created patient is called
		Patient p1 = a.patients.get(0);
		// a new appointment is made for the patient
		p1.makeNewAppointment("11/9/01", "test");
		// all the values are tested against what they are expected to be, thus
		// proving the
		// information is stored by the appointment manager
		assertEquals("Joe Bloggs", p1.getName());
		assertEquals("64 Zoo Lane", p1.getAddress());
		assertEquals("0776326494", p1.getPhonenumber());
		assertEquals("25/12/1995", p1.getDob());
		assertEquals("11/9/01", p1.appointments.get(0).getDate());
		assertEquals("test", p1.appointments.get(0).getDescription());
	}

	// feature 4
	@Test
	public void testid() {
		// Two separate patients are added to the appointment manager
		a.addPatient("Joe Bloggs", "64 Zoo Lane", "0776326494", "25/12/1995");
		a.addPatient("Jim Bloggs", "42 Bleeker Street", "03700100100", "5/5/2005");
		Patient p1 = a.patients.get(0);
		Patient p2 = a.patients.get(1);
		// their id's are not equal- therefore they are unique for this data set
		assertNotEquals(p1.getId(), p2.getId());

	}

	// feature 5
	@Test
	public void testpatientlist() {
		// two patients are added to the appointment manager
		a.addPatient("Joe Bloggs", "64 Zoo Lane", "0776326494", "25/12/1995");
		a.addPatient("Jim Bloggs", "42 Bleeker Street", "03700100100", "5/5/2005");
		Patient p1 = a.patients.get(0);
		// the first patient is given some appointments
		p1.makeNewAppointment("11/9/01", "test");
		p1.makeNewAppointment("24/02/1997", "Happy Birthday");
		// the 'get patients' method returns data
		assertNotNull(a.getpatients());

	}

}
