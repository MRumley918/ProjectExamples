package com.example.tddCoursework;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExampleLoggingTest extends AbstractLoggingJUnitTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void test2() {
		assertTrue(true);
	}

}
