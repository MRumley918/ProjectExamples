#!/bin/sh
chmod og-w . class/config assets
rm -fr install install.php
