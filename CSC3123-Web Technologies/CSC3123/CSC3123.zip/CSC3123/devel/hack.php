<?php
/**
 * You can put arbitrary code in here and run it
 */
    Context::getinstance()->local()->message(\Framework\Local::MESSAGE, 'Done');
?>
