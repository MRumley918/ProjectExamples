<?php
    namespace Config;
    class Config
    {
	const BASEDNAME	= '/csc3123';
	const DBHOST	= 'localhost';
	const DB	= 'csc3123';
	const DBUSER	= 'root';
	const DBPW	= '';
	const SITENAME	= 'CSC3123';
	const SITEURL	= 'http://localhost.org//CSC3123/';
	const SITENOREPLY	= 'M.Rumley1@newcastle.ac.uk';
	const SYSADMIN	= 'M.Rumley1@newcastle.ac.uk';
	const DBRX	= FALSE;
	const UPUBLIC	= FALSE;
	const UPRIVATE	= TRUE;
	const USEPHPM	= FALSE;

        public static function setup()
        {
            \Framework\Web\Web::getinstance()->addheader([
            'Date'			=> gmstrftime('%b %d %Y %H:%M:%S', time()),
            'Window-target'		=> '_top',	# deframes things
            'X-Frame-Options'	=> 'DENY',	# deframes things
            'Content-Language'	=> 'en',
            'Vary'			=> 'Accept-Encoding',
            ]);
        }
    }
?>