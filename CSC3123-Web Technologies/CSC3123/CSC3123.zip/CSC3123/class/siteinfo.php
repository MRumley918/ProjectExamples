<?php
/**
 * A class that contains code to return info needed in various places on the site
 *
 * @author Lindsay Marshall <lindsay.marshall@ncl.ac.uk>
 * @copyright 2016-2017 Newcastle University
 *
 */
/**
 * Utility class that returns generally useful information about parts of the site
 * The parent class (FWSiteInfo) contains a set of functions that are used by the
 * admin pages of the site.
 */
    class SiteInfo extends \Framework\SiteInfo
    {
/**
 * Get all the module beans
 *
 * @param integer   $start      Start position - used for pagination
 * @param integer   $count      The number to be fetched - used for pagination
 * @param string    $order      An order clause
 * @param boolean   $collect    If TRUE then use collect not fetch
 *
 * @return array
 */
		public function modules($start = '', $count = '', $order = '', $collect = FALSE)
        {
            return $this->{$collect ? 'collect' : 'fetch'}('modules', $order !== '' ? $order : ' order by name', [], $start, $count);
        }
/**
 * Get all the paper beans
 *
 * @param integer   $start      Start position - used for pagination
 * @param integer   $count      The number to be fetched - used for pagination
 * @param string    $order      An order clause
 * @param boolean   $collect    If TRUE then use collect not fetch
 *
 * @return array
 */
		public function papers($start = '', $count = '', $order = '', $collect = FALSE)
        {
            return $this->{$collect ? 'collect' : 'fetch'}('papers', $order !== '' ? $order : ' order by name', [], $start, $count);
        }
/**
 * Get all the upload beans
 *
 * @param integer   $start      Start position - used for pagination
 * @param integer   $count      The number to be fetched - used for pagination
 * @param string    $order      An order clause
 * @param boolean   $collect    If TRUE then use collect not fetch
 *
 * @return array
 */
		public function uploads($start = '', $count = '', $order = '', $collect = FALSE)
        {
            return $this->{$collect ? 'collect' : 'fetch'}('upload', $order !== '' ? $order : ' order by id', [], $start, $count);
        }
    }
?>
