<?php
/**
 * A class that handles Ajax calls
 *
 * @author Lindsay Marshall <lindsay.marshall@ncl.ac.uk>
 * @copyright 2017 Newcastle University
 *
 */
/**
 * Handles Ajax Calls.
 */
    class Ajax extends \Framework\Ajax
    {
/**
 * Any Ajax for your system goes in here.
 *
 *********  Make sure that you call the parent handle method for anything you are not handling yourself!! ***********
 */
/*
        public function yourop($context)
        {
            // your code
        }
 */
/**
 * Handle AJAX operations
 *
 * @param object	$context	The context object for the site
 *
 * @return void
 */
 
		
        public function handle($context)
        {
            //$this->operation('yourop', [TRUE, [['ContextName', 'RoleName']]]); // TRUE if login needed, array is a list of roles required  in form ['context name', 'role name']
            parent::handle($context);
        }
/**
 * Add a Paper
 *
 * @param object	$context	The context object for the site
 *
 * @return void
 */
		public function addpaper($context)
        {
			$year = date('Y');
            $p = R::dispense('papers');
            $p->name = $context->formdata()->mustpost('name');
            $p->module = $context->formdata()->mustpost('module');
			$p->marker = $context->formdata()->mustpost('marker');
			$p->date = $context->formdata()->mustpost('date');
			//is the paper from the current year?
			if($p->date === $year){
				$p->past=0;
			}
			else{
				$p->past=1;
			}
            R::store($p);
            echo $p->getID();
        }
/**
 * Add a Module
 *
 * @param object	$context	The context object for the site
 *
 * @return void
 */
		public function addmodule($context)
        {
            $p = R::dispense('modules');
            $p->name = $context->formdata()->mustpost('name');
            $p->code = $context->formdata()->mustpost('code');
			$p->moduleleader = $context->formdata()->mustpost('moduleleader');
			$p->moduleexaminer = $context->formdata()->mustpost('moduleexaminer');
            R::store($p);
            echo $p->getID();
        }
		
    }
?>
